Skud.ME Kodi
===
Skud.ME é uma addon para Kodi

License: [GPL v.3](http://www.gnu.org/copyleft/gpl.html)
